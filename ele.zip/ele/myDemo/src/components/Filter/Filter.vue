<template>
    <div class="filter">
        <ul>
            <li>
                综合排序
                <i class="iconfont icon-xiala"></i>
            </li>
            <li>距离最近</li>
            <li>品牌联盟</li>
            <li>
                筛选
                <i class="iconfont icon-shaixuan"></i>
            </li>
        </ul>
    </div>
</template>
<style lang="scss" scoped>
    .filter{
        width: 100%;
        background-color: #fff;
        ul{
            display: flex;
            height: .8rem;
            justify-content: space-between;
            align-items: center;
            padding-right: .64rem;
            padding-left: .4533rem;
        }
    }
</style>
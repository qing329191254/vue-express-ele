<template>
    <router-view></router-view>
    <Toolbar></Toolbar>
</template>
<script setup>
    import Toolbar from '@/components/toolbar/toolbar.vue'
</script>
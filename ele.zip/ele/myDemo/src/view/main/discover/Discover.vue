<script setup>
    import headerTop from "@/components/header/header.vue";
</script>
<template>
    <headerTop title='发现'>
    </headerTop>
</template>